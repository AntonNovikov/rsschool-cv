# rsschool-cv
https://antonnovikov.github.io/rsschool-cv/
https://antonnovikov.github.io/rsschool-cv/cv